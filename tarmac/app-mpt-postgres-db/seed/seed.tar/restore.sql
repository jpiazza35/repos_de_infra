--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Market_Pricing_DB";
--
-- Name: Market_Pricing_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Market_Pricing_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE "Market_Pricing_DB" OWNER TO postgres;

\connect "Market_Pricing_DB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adjustment_note_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adjustment_note_list (
    adjustment_note_key integer NOT NULL,
    adjustment_note_name character varying(100) NOT NULL,
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone
);


ALTER TABLE public.adjustment_note_list OWNER TO postgres;

--
-- Name: adjustment_note_list_adjustment_note_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.adjustment_note_list ALTER COLUMN adjustment_note_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.adjustment_note_list_adjustment_note_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: benchmark_data_type_setup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.benchmark_data_type_setup (
    benchmark_data_type_key integer NOT NULL,
    benchmark_data_type_name character(100),
    benchmark_data_type_long_alias character(100),
    benchmark_data_type_short_alias character(50),
    benchmark_data_type_order_override integer,
    benchmark_data_type_format character(50),
    benchmark_data_type_format_decimal integer
);


ALTER TABLE public.benchmark_data_type_setup OWNER TO postgres;

--
-- Name: market_pricing_sheet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_pricing_sheet (
    market_pricing_sheet_id integer NOT NULL,
    project_version_id integer,
    aggregation_method_key smallint,
    ces_org_id integer,
    job_code character varying(255),
    job_title character varying(255),
    market_pricing_job_code character varying(255),
    market_pricing_job_title character varying(255),
    job_group character varying(255),
    position_code character varying(255),
    market_segment_id integer,
    status_key integer,
    status_change_date timestamp without time zone,
    job_match_note character varying(1000),
    job_decription_selection character varying(100),
    is_job_description_overwritten boolean,
    market_pricing_job_description character varying(8000),
    market_pricing_sheet_name character varying(100),
    market_pricing_sheet_note character varying(1000),
    publisher_name character varying(255),
    publisher_key integer,
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone,
    no_benchmark_match boolean DEFAULT false
);


ALTER TABLE public.market_pricing_sheet OWNER TO postgres;

--
-- Name: market_pricing_sheet_adjustment_note; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_pricing_sheet_adjustment_note (
    market_pricing_sheet_adjustment_note_key integer NOT NULL,
    market_pricing_sheet_survey_key integer,
    adjustment_note_key integer,
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone
);


ALTER TABLE public.market_pricing_sheet_adjustment_note OWNER TO postgres;

--
-- Name: market_pricing_sheet_adjustme_market_pricing_sheet_adjustme_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_pricing_sheet_adjustment_note ALTER COLUMN market_pricing_sheet_adjustment_note_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_pricing_sheet_adjustme_market_pricing_sheet_adjustme_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_pricing_sheet_cut_external; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_pricing_sheet_cut_external (
    cut_external_key integer NOT NULL,
    project_version_id integer,
    market_pricing_sheet_id integer,
    standard_job_code character varying(100),
    standard_job_title character varying(100),
    external_publisher_name character varying(100),
    external_survey_name character varying(100),
    external_survey_year integer,
    external_survey_job_code character varying(100),
    external_survey_job_title character varying(100),
    external_industry_sector_name character varying(100),
    external_organization_type_name character varying(100),
    external_cut_group_name character varying(100),
    external_cut_sub_group_name character varying(100),
    external_market_pricing_cut_name character varying(100),
    external_survey_cut_name character varying(100),
    external_survey_effective_date timestamp without time zone,
    incumbent_count integer,
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.market_pricing_sheet_cut_external OWNER TO postgres;

--
-- Name: market_pricing_sheet_cut_external_cut_external_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_pricing_sheet_cut_external ALTER COLUMN cut_external_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_pricing_sheet_cut_external_cut_external_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_pricing_sheet_cut_external_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_pricing_sheet_cut_external_data (
    cut_external_data_key integer NOT NULL,
    cut_external_key integer,
    benchmark_data_type_key integer,
    benchmark_data_type_value numeric(18,6),
    percentile_number smallint,
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone
);


ALTER TABLE public.market_pricing_sheet_cut_external_data OWNER TO postgres;

--
-- Name: market_pricing_sheet_cut_external_dat_cut_external_data_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_pricing_sheet_cut_external_data ALTER COLUMN cut_external_data_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_pricing_sheet_cut_external_dat_cut_external_data_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_pricing_sheet_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_pricing_sheet_file (
    project_version_id integer NOT NULL,
    market_pricing_sheet_id integer NOT NULL,
    file_s3_url character varying(1024),
    file_s3_name character varying(300),
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.market_pricing_sheet_file OWNER TO postgres;

--
-- Name: market_pricing_sheet_job_match; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_pricing_sheet_job_match (
    job_match_key integer NOT NULL,
    market_pricing_sheet_id integer,
    standard_job_code character varying(100),
    standard_job_title character varying(100),
    standard_job_description character varying(8000),
    blend_percent numeric(5,2),
    blend_note character varying(1000),
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone
);


ALTER TABLE public.market_pricing_sheet_job_match OWNER TO postgres;

--
-- Name: market_pricing_sheet_job_match_job_match_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_pricing_sheet_job_match ALTER COLUMN job_match_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_pricing_sheet_job_match_job_match_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_pricing_sheet_market_pricing_sheet_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_pricing_sheet ALTER COLUMN market_pricing_sheet_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_pricing_sheet_market_pricing_sheet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_pricing_sheet_survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_pricing_sheet_survey (
    market_pricing_sheet_survey_key integer NOT NULL,
    market_pricing_sheet_id integer,
    market_segment_cut_detail_key integer,
    cut_external_key integer,
    raw_data_key bigint,
    exclude_in_calc boolean,
    adjustment_value numeric(5,2),
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone
);


ALTER TABLE public.market_pricing_sheet_survey OWNER TO postgres;

--
-- Name: market_pricing_sheet_survey_market_pricing_sheet_survey_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_pricing_sheet_survey ALTER COLUMN market_pricing_sheet_survey_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_pricing_sheet_survey_market_pricing_sheet_survey_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_segment_blend; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_segment_blend (
    market_segment_blend_key integer NOT NULL,
    parent_market_segment_cut_key integer,
    child_market_segment_cut_key integer,
    blend_weight numeric(5,2),
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.market_segment_blend OWNER TO postgres;

--
-- Name: market_segment_blend_market_segment_blend_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_segment_blend ALTER COLUMN market_segment_blend_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_segment_blend_market_segment_blend_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_segment_combined_averages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_segment_combined_averages (
    combined_averages_key integer NOT NULL,
    market_segment_id integer,
    combined_averages_name character varying(100) NOT NULL,
    combined_averages_order integer NOT NULL,
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.market_segment_combined_averages OWNER TO postgres;

--
-- Name: market_segment_combined_averages_cut; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_segment_combined_averages_cut (
    combined_averages_cut_key integer NOT NULL,
    combined_averages_key integer,
    market_pricing_cut_name character varying(100) NOT NULL,
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.market_segment_combined_averages_cut OWNER TO postgres;

--
-- Name: market_segment_combined_averages__combined_averages_cut_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_segment_combined_averages_cut ALTER COLUMN combined_averages_cut_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_segment_combined_averages__combined_averages_cut_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_segment_combined_averages_combined_averages_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_segment_combined_averages ALTER COLUMN combined_averages_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_segment_combined_averages_combined_averages_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_segment_cut; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_segment_cut (
    market_segment_cut_key integer NOT NULL,
    market_segment_id integer NOT NULL,
    is_blend_flag boolean,
    industry_sector_key integer,
    organization_type_key integer,
    cut_group_key integer,
    cut_sub_group_key integer,
    market_pricing_cut_name character varying(100),
    display_on_report_flag boolean,
    report_order integer,
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.market_segment_cut OWNER TO postgres;

--
-- Name: market_segment_cut_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_segment_cut_detail (
    market_segment_cut_detail_key integer NOT NULL,
    market_segment_cut_key integer,
    publisher_key integer,
    survey_key integer,
    industry_sector_key integer,
    organization_type_key integer,
    cut_group_key integer,
    cut_sub_group_key integer,
    cut_key integer,
    is_selected boolean,
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.market_segment_cut_detail OWNER TO postgres;

--
-- Name: market_segment_cut_detail_market_segment_cut_detail_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_segment_cut_detail ALTER COLUMN market_segment_cut_detail_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_segment_cut_detail_market_segment_cut_detail_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_segment_cut_market_segment_cut_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_segment_cut ALTER COLUMN market_segment_cut_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_segment_cut_market_segment_cut_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: market_segment_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_segment_list (
    market_segment_id integer NOT NULL,
    project_version_id integer NOT NULL,
    market_segment_name character varying(100) NOT NULL,
    market_segment_status_key integer,
    eri_adjustment_factor numeric(5,2),
    eri_cut_name character varying(100),
    eri_city character varying(100),
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.market_segment_list OWNER TO postgres;

--
-- Name: market_segment_list_market_segment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.market_segment_list ALTER COLUMN market_segment_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.market_segment_list_market_segment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project_benchmark_data_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_benchmark_data_type (
    project_benchmark_data_type_id integer NOT NULL,
    project_version_id integer NOT NULL,
    benchmark_data_type_key integer NOT NULL,
    aging_factor_override numeric(18,2),
    override_comment character varying(1000),
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.project_benchmark_data_type OWNER TO postgres;

--
-- Name: project_benchmark_data_type_project_benchmark_data_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.project_benchmark_data_type ALTER COLUMN project_benchmark_data_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_benchmark_data_type_project_benchmark_data_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_list (
    project_id integer NOT NULL,
    org_key integer NOT NULL,
    project_name character varying(100) NOT NULL,
    survey_source_group_key integer,
    project_status_key integer,
    project_status_modified_utc_datetime timestamp without time zone NOT NULL,
    project_created_utc_datetime timestamp without time zone NOT NULL,
    emulated_by character varying(100),
    modified_username character varying(100),
    modified_utc_datetime timestamp without time zone
);


ALTER TABLE public.project_list OWNER TO postgres;

--
-- Name: project_list_project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.project_list ALTER COLUMN project_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_list_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: project_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_version (
    project_version_id integer NOT NULL,
    project_id integer NOT NULL,
    project_version_label character varying(100),
    project_version_datetime timestamp without time zone NOT NULL,
    project_version_status_key integer,
    project_version_status_notes character varying(1000),
    file_log_key integer,
    aggregation_methodology_key integer,
    emulated_by character varying(100),
    modified_username character varying(100) NOT NULL,
    modified_utc_datetime timestamp without time zone NOT NULL,
    main_settings_json json
);


ALTER TABLE public.project_version OWNER TO postgres;

--
-- Name: project_version_project_version_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.project_version ALTER COLUMN project_version_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.project_version_project_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: status_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_list (
    status_key integer NOT NULL,
    status_name character varying(100),
    status_description character varying(200),
    status_type character varying(20),
    display_status boolean
);


ALTER TABLE public.status_list OWNER TO postgres;

--
-- Data for Name: adjustment_note_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adjustment_note_list (adjustment_note_key, adjustment_note_name, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.adjustment_note_list (adjustment_note_key, adjustment_note_name, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3495.dat';

--
-- Data for Name: benchmark_data_type_setup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.benchmark_data_type_setup (benchmark_data_type_key, benchmark_data_type_name, benchmark_data_type_long_alias, benchmark_data_type_short_alias, benchmark_data_type_order_override, benchmark_data_type_format, benchmark_data_type_format_decimal) FROM stdin;
\.
COPY public.benchmark_data_type_setup (benchmark_data_type_key, benchmark_data_type_name, benchmark_data_type_long_alias, benchmark_data_type_short_alias, benchmark_data_type_order_override, benchmark_data_type_format, benchmark_data_type_format_decimal) FROM '$$PATH$$/3501.dat';

--
-- Data for Name: market_pricing_sheet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_pricing_sheet (market_pricing_sheet_id, project_version_id, aggregation_method_key, ces_org_id, job_code, job_title, market_pricing_job_code, market_pricing_job_title, job_group, position_code, market_segment_id, status_key, status_change_date, job_match_note, job_decription_selection, is_job_description_overwritten, market_pricing_job_description, market_pricing_sheet_name, market_pricing_sheet_note, publisher_name, publisher_key, emulated_by, modified_username, modified_utc_datetime, no_benchmark_match) FROM stdin;
\.
COPY public.market_pricing_sheet (market_pricing_sheet_id, project_version_id, aggregation_method_key, ces_org_id, job_code, job_title, market_pricing_job_code, market_pricing_job_title, job_group, position_code, market_segment_id, status_key, status_change_date, job_match_note, job_decription_selection, is_job_description_overwritten, market_pricing_job_description, market_pricing_sheet_name, market_pricing_sheet_note, publisher_name, publisher_key, emulated_by, modified_username, modified_utc_datetime, no_benchmark_match) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: market_pricing_sheet_adjustment_note; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_pricing_sheet_adjustment_note (market_pricing_sheet_adjustment_note_key, market_pricing_sheet_survey_key, adjustment_note_key, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_pricing_sheet_adjustment_note (market_pricing_sheet_adjustment_note_key, market_pricing_sheet_survey_key, adjustment_note_key, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3493.dat';

--
-- Data for Name: market_pricing_sheet_cut_external; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_pricing_sheet_cut_external (cut_external_key, project_version_id, market_pricing_sheet_id, standard_job_code, standard_job_title, external_publisher_name, external_survey_name, external_survey_year, external_survey_job_code, external_survey_job_title, external_industry_sector_name, external_organization_type_name, external_cut_group_name, external_cut_sub_group_name, external_market_pricing_cut_name, external_survey_cut_name, external_survey_effective_date, incumbent_count, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_pricing_sheet_cut_external (cut_external_key, project_version_id, market_pricing_sheet_id, standard_job_code, standard_job_title, external_publisher_name, external_survey_name, external_survey_year, external_survey_job_code, external_survey_job_title, external_industry_sector_name, external_organization_type_name, external_cut_group_name, external_cut_sub_group_name, external_market_pricing_cut_name, external_survey_cut_name, external_survey_effective_date, incumbent_count, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3497.dat';

--
-- Data for Name: market_pricing_sheet_cut_external_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_pricing_sheet_cut_external_data (cut_external_data_key, cut_external_key, benchmark_data_type_key, benchmark_data_type_value, percentile_number, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_pricing_sheet_cut_external_data (cut_external_data_key, cut_external_key, benchmark_data_type_key, benchmark_data_type_value, percentile_number, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3499.dat';

--
-- Data for Name: market_pricing_sheet_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_pricing_sheet_file (project_version_id, market_pricing_sheet_id, file_s3_url, file_s3_name, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_pricing_sheet_file (project_version_id, market_pricing_sheet_id, file_s3_url, file_s3_name, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3500.dat';

--
-- Data for Name: market_pricing_sheet_job_match; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_pricing_sheet_job_match (job_match_key, market_pricing_sheet_id, standard_job_code, standard_job_title, standard_job_description, blend_percent, blend_note, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_pricing_sheet_job_match (job_match_key, market_pricing_sheet_id, standard_job_code, standard_job_title, standard_job_description, blend_percent, blend_note, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3489.dat';

--
-- Data for Name: market_pricing_sheet_survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_pricing_sheet_survey (market_pricing_sheet_survey_key, market_pricing_sheet_id, market_segment_cut_detail_key, cut_external_key, raw_data_key, exclude_in_calc, adjustment_value, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_pricing_sheet_survey (market_pricing_sheet_survey_key, market_pricing_sheet_id, market_segment_cut_detail_key, cut_external_key, raw_data_key, exclude_in_calc, adjustment_value, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3491.dat';

--
-- Data for Name: market_segment_blend; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_segment_blend (market_segment_blend_key, parent_market_segment_cut_key, child_market_segment_cut_key, blend_weight, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_segment_blend (market_segment_blend_key, parent_market_segment_cut_key, child_market_segment_cut_key, blend_weight, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3477.dat';

--
-- Data for Name: market_segment_combined_averages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_segment_combined_averages (combined_averages_key, market_segment_id, combined_averages_name, combined_averages_order, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_segment_combined_averages (combined_averages_key, market_segment_id, combined_averages_name, combined_averages_order, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: market_segment_combined_averages_cut; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_segment_combined_averages_cut (combined_averages_cut_key, combined_averages_key, market_pricing_cut_name, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_segment_combined_averages_cut (combined_averages_cut_key, combined_averages_key, market_pricing_cut_name, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: market_segment_cut; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_segment_cut (market_segment_cut_key, market_segment_id, is_blend_flag, industry_sector_key, organization_type_key, cut_group_key, cut_sub_group_key, market_pricing_cut_name, display_on_report_flag, report_order, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_segment_cut (market_segment_cut_key, market_segment_id, is_blend_flag, industry_sector_key, organization_type_key, cut_group_key, cut_sub_group_key, market_pricing_cut_name, display_on_report_flag, report_order, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: market_segment_cut_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_segment_cut_detail (market_segment_cut_detail_key, market_segment_cut_key, publisher_key, survey_key, industry_sector_key, organization_type_key, cut_group_key, cut_sub_group_key, cut_key, is_selected, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_segment_cut_detail (market_segment_cut_detail_key, market_segment_cut_key, publisher_key, survey_key, industry_sector_key, organization_type_key, cut_group_key, cut_sub_group_key, cut_key, is_selected, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3481.dat';

--
-- Data for Name: market_segment_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_segment_list (market_segment_id, project_version_id, market_segment_name, market_segment_status_key, eri_adjustment_factor, eri_cut_name, eri_city, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.market_segment_list (market_segment_id, project_version_id, market_segment_name, market_segment_status_key, eri_adjustment_factor, eri_cut_name, eri_city, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3475.dat';

--
-- Data for Name: project_benchmark_data_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_benchmark_data_type (project_benchmark_data_type_id, project_version_id, benchmark_data_type_key, aging_factor_override, override_comment, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.project_benchmark_data_type (project_benchmark_data_type_id, project_version_id, benchmark_data_type_key, aging_factor_override, override_comment, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3473.dat';

--
-- Data for Name: project_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_list (project_id, org_key, project_name, survey_source_group_key, project_status_key, project_status_modified_utc_datetime, project_created_utc_datetime, emulated_by, modified_username, modified_utc_datetime) FROM stdin;
\.
COPY public.project_list (project_id, org_key, project_name, survey_source_group_key, project_status_key, project_status_modified_utc_datetime, project_created_utc_datetime, emulated_by, modified_username, modified_utc_datetime) FROM '$$PATH$$/3468.dat';

--
-- Data for Name: project_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_version (project_version_id, project_id, project_version_label, project_version_datetime, project_version_status_key, project_version_status_notes, file_log_key, aggregation_methodology_key, emulated_by, modified_username, modified_utc_datetime, main_settings_json) FROM stdin;
\.
COPY public.project_version (project_version_id, project_id, project_version_label, project_version_datetime, project_version_status_key, project_version_status_notes, file_log_key, aggregation_methodology_key, emulated_by, modified_username, modified_utc_datetime, main_settings_json) FROM '$$PATH$$/3470.dat';

--
-- Data for Name: status_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_list (status_key, status_name, status_description, status_type, display_status) FROM stdin;
\.
COPY public.status_list (status_key, status_name, status_description, status_type, display_status) FROM '$$PATH$$/3471.dat';

--
-- Name: adjustment_note_list_adjustment_note_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adjustment_note_list_adjustment_note_key_seq', 4, true);


--
-- Name: market_pricing_sheet_adjustme_market_pricing_sheet_adjustme_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_pricing_sheet_adjustme_market_pricing_sheet_adjustme_seq', 1, true);


--
-- Name: market_pricing_sheet_cut_external_cut_external_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_pricing_sheet_cut_external_cut_external_key_seq', 1, false);


--
-- Name: market_pricing_sheet_cut_external_dat_cut_external_data_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_pricing_sheet_cut_external_dat_cut_external_data_key_seq', 1, false);


--
-- Name: market_pricing_sheet_job_match_job_match_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_pricing_sheet_job_match_job_match_key_seq', 2, true);


--
-- Name: market_pricing_sheet_market_pricing_sheet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_pricing_sheet_market_pricing_sheet_id_seq', 12, true);


--
-- Name: market_pricing_sheet_survey_market_pricing_sheet_survey_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_pricing_sheet_survey_market_pricing_sheet_survey_key_seq', 1, true);


--
-- Name: market_segment_blend_market_segment_blend_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_segment_blend_market_segment_blend_key_seq', 2, true);


--
-- Name: market_segment_combined_averages__combined_averages_cut_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_segment_combined_averages__combined_averages_cut_key_seq', 3, true);


--
-- Name: market_segment_combined_averages_combined_averages_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_segment_combined_averages_combined_averages_key_seq', 1, true);


--
-- Name: market_segment_cut_detail_market_segment_cut_detail_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_segment_cut_detail_market_segment_cut_detail_key_seq', 254, true);


--
-- Name: market_segment_cut_market_segment_cut_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_segment_cut_market_segment_cut_key_seq', 28, true);


--
-- Name: market_segment_list_market_segment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_segment_list_market_segment_id_seq', 2, true);


--
-- Name: project_benchmark_data_type_project_benchmark_data_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_benchmark_data_type_project_benchmark_data_type_id_seq', 10, true);


--
-- Name: project_list_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_list_project_id_seq', 3, true);


--
-- Name: project_version_project_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_version_project_version_id_seq', 3, true);


--
-- Name: adjustment_note_list adjustment_note_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustment_note_list
    ADD CONSTRAINT adjustment_note_pkey PRIMARY KEY (adjustment_note_key);


--
-- Name: benchmark_data_type_setup benchmark_data_type_setup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benchmark_data_type_setup
    ADD CONSTRAINT benchmark_data_type_setup_pkey PRIMARY KEY (benchmark_data_type_key);


--
-- Name: market_pricing_sheet_cut_external cut_external_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_cut_external
    ADD CONSTRAINT cut_external_pkey PRIMARY KEY (cut_external_key);


--
-- Name: market_pricing_sheet_adjustment_note market_pricing_sheet_adjustment_note_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_adjustment_note
    ADD CONSTRAINT market_pricing_sheet_adjustment_note_pkey PRIMARY KEY (market_pricing_sheet_adjustment_note_key);


--
-- Name: market_pricing_sheet_cut_external_data market_pricing_sheet_cut_external_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_cut_external_data
    ADD CONSTRAINT market_pricing_sheet_cut_external_data_pkey PRIMARY KEY (cut_external_data_key);


--
-- Name: market_pricing_sheet_file market_pricing_sheet_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_file
    ADD CONSTRAINT market_pricing_sheet_file_pkey PRIMARY KEY (project_version_id, market_pricing_sheet_id);


--
-- Name: market_pricing_sheet_job_match market_pricing_sheet_job_match_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_job_match
    ADD CONSTRAINT market_pricing_sheet_job_match_pkey PRIMARY KEY (job_match_key);


--
-- Name: market_pricing_sheet market_pricing_sheet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet
    ADD CONSTRAINT market_pricing_sheet_pkey PRIMARY KEY (market_pricing_sheet_id);


--
-- Name: market_pricing_sheet_survey market_pricing_sheet_survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_survey
    ADD CONSTRAINT market_pricing_sheet_survey_pkey PRIMARY KEY (market_pricing_sheet_survey_key);


--
-- Name: market_segment_blend market_segment_blend_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_blend
    ADD CONSTRAINT market_segment_blend_pkey PRIMARY KEY (market_segment_blend_key);


--
-- Name: market_segment_combined_averages_cut market_segment_combined_averages_cut_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_combined_averages_cut
    ADD CONSTRAINT market_segment_combined_averages_cut_pkey PRIMARY KEY (combined_averages_cut_key);


--
-- Name: market_segment_combined_averages market_segment_combined_averages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_combined_averages
    ADD CONSTRAINT market_segment_combined_averages_pkey PRIMARY KEY (combined_averages_key);


--
-- Name: market_segment_cut_detail market_segment_cut_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_cut_detail
    ADD CONSTRAINT market_segment_cut_detail_pkey PRIMARY KEY (market_segment_cut_detail_key);


--
-- Name: market_segment_cut market_segment_cut_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_cut
    ADD CONSTRAINT market_segment_cut_pkey PRIMARY KEY (market_segment_cut_key);


--
-- Name: market_segment_list market_segment_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_list
    ADD CONSTRAINT market_segment_list_pkey PRIMARY KEY (market_segment_id);


--
-- Name: project_benchmark_data_type project_benchmark_data_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_benchmark_data_type
    ADD CONSTRAINT project_benchmark_data_type_pkey PRIMARY KEY (project_benchmark_data_type_id);


--
-- Name: project_list project_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_list
    ADD CONSTRAINT project_list_pkey PRIMARY KEY (project_id);


--
-- Name: project_version project_version_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_version
    ADD CONSTRAINT project_version_pkey PRIMARY KEY (project_version_id);


--
-- Name: status_list status_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_list
    ADD CONSTRAINT status_list_pkey PRIMARY KEY (status_key);


--
-- Name: market_segment_cut unique_market_pricing_cut; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_cut
    ADD CONSTRAINT unique_market_pricing_cut UNIQUE (market_segment_id, industry_sector_key, organization_type_key, cut_group_key, cut_sub_group_key);


--
-- Name: adjustment_note_list unq_adjustment_note_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustment_note_list
    ADD CONSTRAINT unq_adjustment_note_name UNIQUE (adjustment_note_name);


--
-- Name: market_segment_combined_averages unq_combined_average_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_combined_averages
    ADD CONSTRAINT unq_combined_average_name UNIQUE (market_segment_id, combined_averages_name);


--
-- Name: market_segment_combined_averages_cut unq_combined_average_name_and_cut; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_combined_averages_cut
    ADD CONSTRAINT unq_combined_average_name_and_cut UNIQUE (combined_averages_key, market_pricing_cut_name);


--
-- Name: idx_market_pricing_cut_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_market_pricing_cut_name ON public.market_segment_combined_averages_cut USING btree (market_pricing_cut_name);


--
-- Name: market_pricing_sheet_adjustment_note market_pricing_sheet_adjustme_market_pricing_sheet_survey__fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_adjustment_note
    ADD CONSTRAINT market_pricing_sheet_adjustme_market_pricing_sheet_survey__fkey FOREIGN KEY (market_pricing_sheet_survey_key) REFERENCES public.market_pricing_sheet_survey(market_pricing_sheet_survey_key) NOT VALID;


--
-- Name: market_pricing_sheet_adjustment_note market_pricing_sheet_adjustment_note_adjustment_note_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_adjustment_note
    ADD CONSTRAINT market_pricing_sheet_adjustment_note_adjustment_note_key_fkey FOREIGN KEY (adjustment_note_key) REFERENCES public.adjustment_note_list(adjustment_note_key) NOT VALID;


--
-- Name: market_pricing_sheet_cut_external_data market_pricing_sheet_cut_external_data_cut_external_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_cut_external_data
    ADD CONSTRAINT market_pricing_sheet_cut_external_data_cut_external_key_fkey FOREIGN KEY (cut_external_key) REFERENCES public.market_pricing_sheet_cut_external(cut_external_key) NOT VALID;


--
-- Name: market_pricing_sheet_survey market_pricing_sheet_survey_cut_external_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_survey
    ADD CONSTRAINT market_pricing_sheet_survey_cut_external_key_fkey FOREIGN KEY (cut_external_key) REFERENCES public.market_pricing_sheet_cut_external(cut_external_key) NOT VALID;


--
-- Name: market_pricing_sheet_survey market_pricing_sheet_survey_market_segment_cut_detail_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_pricing_sheet_survey
    ADD CONSTRAINT market_pricing_sheet_survey_market_segment_cut_detail_key_fkey FOREIGN KEY (market_segment_cut_detail_key) REFERENCES public.market_segment_cut_detail(market_segment_cut_detail_key) NOT VALID;


--
-- Name: market_segment_blend market_segment_blend_child_market_segment_cut_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_blend
    ADD CONSTRAINT market_segment_blend_child_market_segment_cut_key_fkey FOREIGN KEY (child_market_segment_cut_key) REFERENCES public.market_segment_cut(market_segment_cut_key) NOT VALID;


--
-- Name: market_segment_blend market_segment_blend_parent_market_segment_cut_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_blend
    ADD CONSTRAINT market_segment_blend_parent_market_segment_cut_key_fkey FOREIGN KEY (parent_market_segment_cut_key) REFERENCES public.market_segment_cut(market_segment_cut_key) NOT VALID;


--
-- Name: market_segment_combined_averages_cut market_segment_combined_averages_cut_combined_averages_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_combined_averages_cut
    ADD CONSTRAINT market_segment_combined_averages_cut_combined_averages_key_fkey FOREIGN KEY (combined_averages_key) REFERENCES public.market_segment_combined_averages(combined_averages_key);


--
-- Name: market_segment_combined_averages market_segment_combined_averages_market_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_combined_averages
    ADD CONSTRAINT market_segment_combined_averages_market_segment_id_fkey FOREIGN KEY (market_segment_id) REFERENCES public.market_segment_list(market_segment_id);


--
-- Name: market_segment_cut_detail market_segment_cut_detail_market_segment_cut_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_cut_detail
    ADD CONSTRAINT market_segment_cut_detail_market_segment_cut_key_fkey FOREIGN KEY (market_segment_cut_key) REFERENCES public.market_segment_cut(market_segment_cut_key) NOT VALID;


--
-- Name: market_segment_cut market_segment_cut_market_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segment_cut
    ADD CONSTRAINT market_segment_cut_market_segment_id_fkey FOREIGN KEY (market_segment_id) REFERENCES public.market_segment_list(market_segment_id) NOT VALID;


--
-- Name: project_benchmark_data_type project_benchmark_data_type_project_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_benchmark_data_type
    ADD CONSTRAINT project_benchmark_data_type_project_version_id_fkey FOREIGN KEY (project_version_id) REFERENCES public.project_version(project_version_id) NOT VALID;


--
-- Name: project_list project_list_project_status_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_list
    ADD CONSTRAINT project_list_project_status_key_fkey FOREIGN KEY (project_status_key) REFERENCES public.status_list(status_key) NOT VALID;


--
-- Name: project_version project_version_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_version
    ADD CONSTRAINT project_version_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project_list(project_id) NOT VALID;


--
-- Name: project_version project_version_project_version_status_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_version
    ADD CONSTRAINT project_version_project_version_status_key_fkey FOREIGN KEY (project_version_status_key) REFERENCES public.status_list(status_key) NOT VALID;


--
-- PostgreSQL database dump complete
--

