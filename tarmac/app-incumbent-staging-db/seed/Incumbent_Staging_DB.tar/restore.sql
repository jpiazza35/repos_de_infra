--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Incumbent_Staging_DB";
--
-- Name: Incumbent_Staging_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Incumbent_Staging_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "Incumbent_Staging_DB" OWNER TO postgres;

\connect "Incumbent_Staging_DB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: file_log_detail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_log_detail (
    file_log_detail_key integer NOT NULL,
    file_log_key integer,
    message_text text,
    created_utc_datetime timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.file_log_detail OWNER TO postgres;

--
-- Name: file_log_detail_file_log_detail_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.file_log_detail ALTER COLUMN file_log_detail_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.file_log_detail_file_log_detail_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mapping (
    category character varying(50) NOT NULL,
    internal_name character varying(100) NOT NULL,
    external_name character varying(100) NOT NULL
);


ALTER TABLE public.mapping OWNER TO postgres;

--
-- Name: raw_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.raw_data (
    raw_data_key integer NOT NULL,
    file_log_key integer,
    file_line_number integer,
    ces_org_id character varying(255),
    ces_org_name character varying(255),
    job_code character varying(255),
    job_title character varying(255),
    incumbent_id character varying(255),
    incumbent_name character varying(255),
    fte_value character varying(255),
    client_job_group character varying(255),
    location_description character varying(255),
    job_family character varying(255),
    pay_grade character varying(255),
    pay_type character varying(255),
    position_code character varying(255),
    position_code_description character varying(255),
    job_level character varying(255),
    job_priority character varying(255),
    department_id character varying(255),
    department_name character varying(255),
    supervisor_id character varying(255),
    supervisor_name character varying(255),
    exemption_status character varying(255),
    union_affiliate character varying(255),
    work_status character varying(255),
    gender character varying(255),
    ethnicity character varying(255),
    date_of_original_licensure character varying(255),
    original_hire_date character varying(255),
    job_date character varying(255),
    credited_yoe character varying(255),
    benchmark_data_type_1 character varying(255),
    benchmark_data_type_2 character varying(255),
    benchmark_data_type_3 character varying(255),
    benchmark_data_type_4 character varying(255),
    benchmark_data_type_5 character varying(255),
    benchmark_data_type_6 character varying(255),
    benchmark_data_type_7 character varying(255),
    benchmark_data_type_8 character varying(255),
    benchmark_data_type_9 character varying(255),
    benchmark_data_type_10 character varying(255),
    benchmark_data_type_11 character varying(255),
    benchmark_data_type_12 character varying(255),
    benchmark_data_type_13 character varying(255),
    benchmark_data_type_14 character varying(255),
    benchmark_data_type_15 character varying(255),
    benchmark_data_type_16 character varying(255),
    benchmark_data_type_17 character varying(255),
    benchmark_data_type_18 character varying(255),
    benchmark_data_type_19 character varying(255),
    benchmark_data_type_20 character varying(255),
    benchmark_data_type_21 character varying(255),
    benchmark_data_type_22 character varying(255),
    benchmark_data_type_23 character varying(255),
    benchmark_data_type_24 character varying(255),
    benchmark_data_type_25 character varying(255),
    benchmark_data_type_26 character varying(255),
    benchmark_data_type_27 character varying(255),
    benchmark_data_type_28 character varying(255),
    benchmark_data_type_29 character varying(255),
    benchmark_data_type_30 character varying(255),
    benchmark_data_type_31 character varying(255),
    benchmark_data_type_32 character varying(255),
    benchmark_data_type_33 character varying(255),
    benchmark_data_type_34 character varying(255),
    benchmark_data_type_35 character varying(255),
    benchmark_data_type_36 character varying(255),
    benchmark_data_type_37 character varying(255),
    benchmark_data_type_38 character varying(255),
    benchmark_data_type_39 character varying(255),
    benchmark_data_type_40 character varying(255),
    benchmark_data_type_41 character varying(255),
    benchmark_data_type_42 character varying(255),
    benchmark_data_type_43 character varying(255),
    benchmark_data_type_44 character varying(255),
    benchmark_data_type_45 character varying(255),
    benchmark_data_type_46 character varying(255),
    benchmark_data_type_47 character varying(255),
    benchmark_data_type_48 character varying(255),
    benchmark_data_type_49 character varying(255),
    benchmark_data_type_50 character varying(255)
);


ALTER TABLE public.raw_data OWNER TO postgres;

--
-- Name: raw_data_raw_data_key_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.raw_data ALTER COLUMN raw_data_key ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.raw_data_raw_data_key_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: raw_data_validation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.raw_data_validation (
    id integer NOT NULL,
    raw_data_key integer NOT NULL,
    file_log_key character varying(255),
    "column" character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    description character varying(255) NOT NULL
);


ALTER TABLE public.raw_data_validation OWNER TO postgres;

--
-- Name: raw_data_validation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.raw_data_validation ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.raw_data_validation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: file_log_detail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_log_detail (file_log_detail_key, file_log_key, message_text, created_utc_datetime) FROM stdin;
\.
COPY public.file_log_detail (file_log_detail_key, file_log_key, message_text, created_utc_datetime) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mapping (category, internal_name, external_name) FROM stdin;
\.
COPY public.mapping (category, internal_name, external_name) FROM '$$PATH$$/3371.dat';

--
-- Data for Name: raw_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.raw_data (raw_data_key, file_log_key, file_line_number, ces_org_id, ces_org_name, job_code, job_title, incumbent_id, incumbent_name, fte_value, client_job_group, location_description, job_family, pay_grade, pay_type, position_code, position_code_description, job_level, job_priority, department_id, department_name, supervisor_id, supervisor_name, exemption_status, union_affiliate, work_status, gender, ethnicity, date_of_original_licensure, original_hire_date, job_date, credited_yoe, benchmark_data_type_1, benchmark_data_type_2, benchmark_data_type_3, benchmark_data_type_4, benchmark_data_type_5, benchmark_data_type_6, benchmark_data_type_7, benchmark_data_type_8, benchmark_data_type_9, benchmark_data_type_10, benchmark_data_type_11, benchmark_data_type_12, benchmark_data_type_13, benchmark_data_type_14, benchmark_data_type_15, benchmark_data_type_16, benchmark_data_type_17, benchmark_data_type_18, benchmark_data_type_19, benchmark_data_type_20, benchmark_data_type_21, benchmark_data_type_22, benchmark_data_type_23, benchmark_data_type_24, benchmark_data_type_25, benchmark_data_type_26, benchmark_data_type_27, benchmark_data_type_28, benchmark_data_type_29, benchmark_data_type_30, benchmark_data_type_31, benchmark_data_type_32, benchmark_data_type_33, benchmark_data_type_34, benchmark_data_type_35, benchmark_data_type_36, benchmark_data_type_37, benchmark_data_type_38, benchmark_data_type_39, benchmark_data_type_40, benchmark_data_type_41, benchmark_data_type_42, benchmark_data_type_43, benchmark_data_type_44, benchmark_data_type_45, benchmark_data_type_46, benchmark_data_type_47, benchmark_data_type_48, benchmark_data_type_49, benchmark_data_type_50) FROM stdin;
\.
COPY public.raw_data (raw_data_key, file_log_key, file_line_number, ces_org_id, ces_org_name, job_code, job_title, incumbent_id, incumbent_name, fte_value, client_job_group, location_description, job_family, pay_grade, pay_type, position_code, position_code_description, job_level, job_priority, department_id, department_name, supervisor_id, supervisor_name, exemption_status, union_affiliate, work_status, gender, ethnicity, date_of_original_licensure, original_hire_date, job_date, credited_yoe, benchmark_data_type_1, benchmark_data_type_2, benchmark_data_type_3, benchmark_data_type_4, benchmark_data_type_5, benchmark_data_type_6, benchmark_data_type_7, benchmark_data_type_8, benchmark_data_type_9, benchmark_data_type_10, benchmark_data_type_11, benchmark_data_type_12, benchmark_data_type_13, benchmark_data_type_14, benchmark_data_type_15, benchmark_data_type_16, benchmark_data_type_17, benchmark_data_type_18, benchmark_data_type_19, benchmark_data_type_20, benchmark_data_type_21, benchmark_data_type_22, benchmark_data_type_23, benchmark_data_type_24, benchmark_data_type_25, benchmark_data_type_26, benchmark_data_type_27, benchmark_data_type_28, benchmark_data_type_29, benchmark_data_type_30, benchmark_data_type_31, benchmark_data_type_32, benchmark_data_type_33, benchmark_data_type_34, benchmark_data_type_35, benchmark_data_type_36, benchmark_data_type_37, benchmark_data_type_38, benchmark_data_type_39, benchmark_data_type_40, benchmark_data_type_41, benchmark_data_type_42, benchmark_data_type_43, benchmark_data_type_44, benchmark_data_type_45, benchmark_data_type_46, benchmark_data_type_47, benchmark_data_type_48, benchmark_data_type_49, benchmark_data_type_50) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: raw_data_validation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.raw_data_validation (id, raw_data_key, file_log_key, "column", value, description) FROM stdin;
\.
COPY public.raw_data_validation (id, raw_data_key, file_log_key, "column", value, description) FROM '$$PATH$$/3370.dat';

--
-- Name: file_log_detail_file_log_detail_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.file_log_detail_file_log_detail_key_seq', 1, false);


--
-- Name: raw_data_raw_data_key_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.raw_data_raw_data_key_seq', 1, false);


--
-- Name: raw_data_validation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.raw_data_validation_id_seq', 1, false);


--
-- Name: file_log_detail file_log_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_log_detail
    ADD CONSTRAINT file_log_detail_pkey PRIMARY KEY (file_log_detail_key);


--
-- Name: mapping mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mapping
    ADD CONSTRAINT mapping_pkey PRIMARY KEY (category, internal_name);


--
-- Name: raw_data raw_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_data
    ADD CONSTRAINT raw_data_pkey PRIMARY KEY (raw_data_key);


--
-- Name: raw_data_validation raw_data_validation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_data_validation
    ADD CONSTRAINT raw_data_validation_pkey PRIMARY KEY (id);


--
-- Name: raw_data_validation raw_data_validation_raw_data_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raw_data_validation
    ADD CONSTRAINT raw_data_validation_raw_data_key_fkey FOREIGN KEY (raw_data_key) REFERENCES public.raw_data(raw_data_key);


--
-- PostgreSQL database dump complete
--

